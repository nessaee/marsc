1. Please check and run 'POA_Camera_Test.py', in this py file, it shows the usage of all APIs.

2. Please copy 'PlayerOneCamera.h' and the dynamic library under the corresponding platform to this directory.
Windows: PlayerOneCamera.dll (if your python is 64bit, please copy dll file from lib\x64 folder)
Linux: libPlayerOneCamera.so, libPlayerOneCamera.so.3, libPlayerOneCamera.so.3.x, libPlayerOneCamera.so.3.x.x
MacOS: libPlayerOneCamera.dylib, libPlayerOneCamera.dylib.3, libPlayerOneCamera.dylib.3.x, libPlayerOneCamera.dylib.3.x.x

If you have any problem or suggestion, please contact us: support@player-one-astronomy.com.
