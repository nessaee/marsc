
Head files:
include/PlayerOneCamera.h: the c header file
include/PlayerOneCameraDLL.cs: the c# wrapper for the DLL

Examples:
please refer to example for using Player One Camera SDK

doc:
Development manual

If you have any questions, please contact us: support@player-one-astronomy.com
