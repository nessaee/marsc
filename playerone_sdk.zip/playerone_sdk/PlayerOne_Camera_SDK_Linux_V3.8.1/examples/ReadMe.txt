'xxxx.pro' is Qt Project, please note that check the 'Run in terminal'(Projects -> Run Settings).

'CMakeLists.txt' is CMake Project, You can use CMake to generate other projects. Note: You may need to copy the dynamic library to the project's runtime(bin) directory.

On Linux, if you want to build examples, you should copy the SDK library(libPlayerOneCamera.so.*) to the 'lib' folder from arm32, arm64 or x64 folder.
